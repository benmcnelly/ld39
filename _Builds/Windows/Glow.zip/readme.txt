
            _____ _                        
  ______   / ____| |                ______ 
 |______| | |  __| | _____      __ |______|
  ______  | | |_ | |/ _ \ \ /\ / /  ______ 
 |______| | |__| | | (_) \ V  V /  |______|
           \_____|_|\___/ \_/\_/           
                                           
                                           
Source: https://github.com/benmcnelly/ld39

Created with:
~ Unity Game Engine
~ Adobe Photoshop
~ 3DS Max
~ Atom Code Editor
~ Audacity

Voice Acting by Daisy @ http://www.fromtexttospeech.com

http://benmcnelly.com
http://fbstudios.com
